package view;

public class NewsView {
    public static void mainView() {
        System.out.println("欢饮来到新闻信息管理系统");
        System.out.println("1、查询\t2、新增\t3、修改\t4、删除\t0、退出");
        System.out.println("********************************");
        System.out.println("请选择：");
    }
}
