package po;

public class News {
    private int id;
    private String title;
    private String type;
    private String content;
    private String Author;
    private String createdate;
    private String modifydate;
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }
    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }
    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }
    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }
    /**
     * @return the type
     */
    public String getType() {
        return type;
    }
    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }
    /**
     * @return the content
     */
    public String getContent() {
        return content;
    }
    /**
     * @param content the content to set
     */
    public void setContent(String content) {
        this.content = content;
    }
    /**
     * @return the author
     */
    public String getAuthor() {
        return Author;
    }
    /**
     * @param author the author to set
     */
    public void setAuthor(String author) {
        Author = author;
    }
    /**
     * @return the createdate
     */
    public String getCreatedate() {
        return createdate;
    }
    /**
     * @param createdate the createdate to set
     */
    public void setCreatedate(String createdate) {
        this.createdate = createdate;
    }
    /**
     * @return the modifydate
     */
    public String getModifydate() {
        return modifydate;
    }
    /**
     * @param modifydate the modifydate to set
     */
    public void setModifydate(String modifydate) {
        this.modifydate = modifydate;
    }
    
}
